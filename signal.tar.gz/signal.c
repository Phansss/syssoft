#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void handler(int signum){
  printf("Hello World!\n");
}

int main(){

  //declare a struct sigaction
  struct sigaction action, oldaction;

  //set the handler
  action.sa_handler = handler;

  //call sigaction with the action structure
  sigaction(SIGALRM, &action, &oldaction);

  //schedule an alarm
  alarm(1);

  //pause
  pause();

  //call sigaction with the action structure
  sigaction(SIGALRM, &oldaction, NULL);

  //schedule an alarm
  alarm(1);

  pause();
}
